package src.main;
import src.view.Janela;

public class Chat {
    public static void main(String[] args) {
        Janela janela = new Janela();
        janela.setVisible(true);
    }
}

                